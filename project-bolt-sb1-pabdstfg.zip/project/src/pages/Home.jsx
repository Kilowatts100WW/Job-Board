import React from 'react';
import { Link } from 'react-router-dom';
import { SearchIcon, BriefcaseIcon, BuildingIcon, UsersIcon } from 'lucide-react';

export default function Home() {
  return (
    <div className="space-y-16">
      <section className="text-center space-y-8">
        <h1 className="text-5xl font-bold text-gray-900">
          Find Your Dream Job Today
        </h1>
        <p className="text-xl text-gray-600 max-w-2xl mx-auto">
          Connect with top employers and discover opportunities that match your skills and aspirations.
        </p>
        <div className="flex justify-center gap-4">
          <Link
            to="/jobs"
            className="bg-blue-600 text-white px-6 py-3 rounded-md hover:bg-blue-700 flex items-center gap-2"
          >
            <SearchIcon className="h-5 w-5" />
            Browse Jobs
          </Link>
          <Link
            to="/register"
            className="bg-white text-blue-600 border border-blue-600 px-6 py-3 rounded-md hover:bg-blue-50"
          >
            Post a Job
          </Link>
        </div>
      </section>

      <section className="grid md:grid-cols-3 gap-8">
        <div className="bg-white p-6 rounded-lg shadow-md text-center">
          <BriefcaseIcon className="h-12 w-12 text-blue-600 mx-auto mb-4" />
          <h3 className="text-xl font-semibold mb-2">Latest Jobs</h3>
          <p className="text-gray-600">
            Access thousands of fresh job opportunities updated daily.
          </p>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-md text-center">
          <BuildingIcon className="h-12 w-12 text-blue-600 mx-auto mb-4" />
          <h3 className="text-xl font-semibold mb-2">Top Companies</h3>
          <p className="text-gray-600">
            Connect with leading companies across industries.
          </p>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-md text-center">
          <UsersIcon className="h-12 w-12 text-blue-600 mx-auto mb-4" />
          <h3 className="text-xl font-semibold mb-2">Career Growth</h3>
          <p className="text-gray-600">
            Find opportunities that align with your career goals.
          </p>
        </div>
      </section>

      <section className="bg-white rounded-lg shadow-md p-8">
        <h2 className="text-3xl font-bold text-center mb-8">Featured Categories</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {['Technology', 'Marketing', 'Design', 'Sales', 'Engineering', 'Finance', 'Healthcare', 'Education'].map((category) => (
            <Link
              key={category}
              to={`/jobs?category=${category.toLowerCase()}`}
              className="p-4 border rounded-md hover:border-blue-600 hover:text-blue-600 text-center"
            >
              {category}
            </Link>
          ))}
        </div>
      </section>
    </div>
  );
}